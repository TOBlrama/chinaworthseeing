<?php

defined('ABSPATH') || die;

use FluentForm\App\Modules\Component\Component;
use FluentForm\App\Modules\Acl\Acl;
use FluentForm\App\Helpers\Helper;
use FluentForm\Framework\Helpers\ArrayHelper;

/**
 * All registered action's handlers should be in app\Hooks\Handlers,
 * addAction is similar to add_action and addCustomAction is just a
 * wrapper over add_action which will add a prefix to the hook name
 * using the plugin slug to make it unique in all WordPress plugins,
 * ex: $app->addCustomAction('foo', ['FooHandler', 'handleFoo']) is
 * equivalent to add_action('slug-foo', ['FooHandler', 'handleFoo']).
 */

/**
 * Application instance.
 *
 * @var $app FluentForm\Framework\Foundation\Application
 */

// From MenuProvider.php
$app->addAction(
    'admin_menu',
    function () use ($app) {
        (new \FluentForm\App\Modules\Registerer\Menu($app))->register();
    }
);

$app->addAction(
    'fluentform/form_application_view_editor',
    function ($formId) use ($app) {
        (new \FluentForm\App\Modules\Registerer\Menu($app))->renderEditor($formId);
    }
);

$app->addAction(
    'fluentform/form_application_view_settings',
    function ($formId) use ($app) {
        (new \FluentForm\App\Modules\Registerer\Menu($app))->renderSettings($formId);
    }
);

$app->addAction(
    'fluentform/form_settings_container_form_settings',
    function ($formId) use ($app) {
        (new \FluentForm\App\Modules\Registerer\Menu($app))->renderFormSettings($formId);
    }
);

$app->addAction(
    'fluentform/global_settings_component_settings',
    function () use ($app) {
        (new \FluentForm\App\Modules\Renderer\GlobalSettings\Settings($app))->render();
    }
);

$app->addAction(
    'fluentform/global_settings_component_reCaptcha',
    function () use ($app) {
        (new \FluentForm\App\Modules\Renderer\GlobalSettings\Settings($app))->render();
    }
);

$app->addAction(
    'fluentform/global_settings_component_hCaptcha',
    function () use ($app) {
        (new \FluentForm\App\Modules\Renderer\GlobalSettings\Settings($app))->render();
    }
);

// Register DefaultStyleApplicator on init so it works for REST API requests too
add_action('init', function () {
    new \FluentForm\App\Modules\Form\DefaultStyleApplicator();
}, 9);

// From Backend.php
add_action('admin_init', function () use ($app) {
    (new \FluentForm\App\Modules\Registerer\Menu($app))->reisterScripts();
    (new \FluentForm\App\Modules\Registerer\AdminBar())->register();
    (new \FluentForm\App\Modules\Ai\AiController())->boot();
    (new \FluentForm\App\Modules\Report\ReportHandler())->register($app);
}, 9);

add_action('admin_enqueue_scripts', function () use ($app) {
    (new \FluentForm\App\Modules\Registerer\Menu($app))->enqueuePageScripts();
}, 10);

// Add Entries Menu
$app->addAction('fluentform/form_application_view_entries', function ($form_id) {
    (new \FluentForm\App\Modules\Entries\EntryViewRenderer())->renderEntries($form_id);
});

$app->addAction('fluentform/after_form_navigation', function ($form_id) use ($app) {
    (new \FluentForm\App\Modules\Registerer\Menu($app))->addCopyShortcodeButton($form_id);
    (new \FluentForm\App\Modules\Registerer\Menu($app))->addPreviewButton($form_id);
});

$app->addAction('media_buttons', function () {
    (new \FluentForm\App\Modules\EditorButtonModule())->addButton();
});

/*
 * Addons Page
 */
$app->addAction('fluentform/addons_page_render_fluentform_add_ons', function () {
    (new \FluentForm\App\Modules\AddOnModule())->showFluentAddOns();
});

$app->addAction('fluentform/addons_page_render_suggested_plugins', function () {
    (new \FluentForm\App\Modules\AddOnModule())->showSuggestedPlugins();
});

$app->addAction('fluentform/global_menu', function () use ($app) {
    $menu = new \FluentForm\App\Modules\Registerer\Menu($app);
    $menu->renderGlobalMenu();
    if ('yes' != get_option('fluentform_scheduled_actions_migrated')) {
        \FluentForm\Database\Migrations\ScheduledActions::migrate();
    }

    $hookName = 'fluentform_do_scheduled_tasks';
    if (!wp_next_scheduled($hookName)) {
        wp_schedule_event(time(), 'ff_every_five_minutes', $hookName);
    }

    $emailReportHookName = 'fluentform_do_email_report_scheduled_tasks';
    if (!wp_next_scheduled($emailReportHookName)) {
        wp_schedule_event(time(), 'daily', $emailReportHookName);
    }
});

$app->addAction('wp_dashboard_setup', function () {
    $acl = new \FluentForm\App\Modules\Acl\Acl();

    if (!$acl::getCurrentUserCapability()) {
        return;
    }
    wp_add_dashboard_widget('fluentform_stat_widget', __('Fluent Forms Latest Form Submissions', 'fluentform'), function () {
        (new \FluentForm\App\Modules\DashboardWidgetModule())->showStat();
    }, 10, 1);
});

add_action('admin_init', function () {
    $disablePages = [
        'fluent_forms',
        'fluent_forms_transfer',
        'fluent_forms_settings',
        'fluent_forms_add_ons',
        'fluent_forms_docs',
        'fluent_forms_all_entries',
        'msformentries',
        'fluent_forms_payment_entries',
        'fluent_forms_reports',
    ];

    $page = wpFluentForm('request')->get('page');

    if ($page && in_array($page, $disablePages)) {
        remove_all_actions('admin_notices');
        \FluentForm\App\Modules\Registerer\ReviewQuery::register();
        \FluentForm\App\Modules\Registerer\MigrationNotice::register();
        \FluentForm\App\Modules\Registerer\StripeKeyNotice::register();
        \FluentForm\App\Modules\Registerer\CaptchaKeyNotice::register();
    }
});

add_action('wp_print_scripts', function () {
    if (is_admin()) {
        if (\FluentForm\App\Helpers\Helper::isFluentAdminPage()) {
            $option = get_option('_fluentform_global_form_settings');
            $isSkip = 'no' == \FluentForm\Framework\Helpers\ArrayHelper::get($option, 'misc.noConflictStatus');

            $isSkip = apply_filters_deprecated(
                'fluentform_skip_no_conflict',
                [
                    $isSkip,
                ],
                FLUENTFORM_FRAMEWORK_UPGRADE,
                'fluentform/skip_no_conflict',
                'Use fluentform/skip_no_conflict instead of fluentform_skip_no_conflict.'
            );

            $isSkip = apply_filters('fluentform/skip_no_conflict', $isSkip);

            if ($isSkip) {
                return;
            }

            global $wp_scripts;
            if (!$wp_scripts) {
                return;
            }

            $pluginUrl = plugins_url();
            // Get an array of slugs to exclude from dequeue
            $excludeSlugs = apply_filters('fluentform/exclude_js_slugs_from_dequeue', ['fluentform']);

            foreach ($wp_scripts->queue as $script) {
                if (!isset($wp_scripts->registered[$script])) {
                    continue;
                }

                $src = $wp_scripts->registered[$script]->src;

                // Check if the script is in the plugins directory
                if (false !== strpos($src, $pluginUrl)) {
                    // Only dequeue if none of the exclude slugs are in the script src
                    $shouldDequeue = true;
                    foreach ($excludeSlugs as $slug) {
                        if (false !== strpos($src, $slug)) {
                            $shouldDequeue = false;
                            break;
                        }
                    }

                    if ($shouldDequeue) {
                        wp_dequeue_script($wp_scripts->registered[$script]->handle);
                    }
                }
            }
        }
    }
}, 1);

$app->addAction('fluentform/loading_editor_assets', function ($form) {
    add_filter('fluentform/editor_init_element_input_name', function ($field) {
        if (empty($field['settings']['label_placement'])) {
            $field['settings']['label_placement'] = '';
        }
        return $field;
    });

    add_filter('fluentform/editor_init_element_step_start', function ($item) {
        if (!isset($item['settings']['progress_layout'])) {
            $item['settings']['progress_layout'] = 'top';
        }

        if (!isset($item['settings']['tabs_show_progress_bar'])) {
            $item['settings']['tabs_show_progress_bar'] = 'no';
        }

        return $item;
    });

    $upgradableCheckInputs = [
        'input_radio',
        'select',
        'select_country',
        'input_checkbox',
    ];
    foreach ($upgradableCheckInputs as $upgradeElement) {
        add_filter('fluentform/editor_init_element_' . $upgradeElement, function ($element) use ($upgradeElement, $form) {

            if (!\FluentForm\Framework\Helpers\ArrayHelper::get($element, 'settings.advanced_options')) {
                $formattedOptions = [];
                $oldOptions = \FluentForm\Framework\Helpers\ArrayHelper::get($element, 'options', []);
                foreach ($oldOptions as $value => $label) {
                    $formattedOptions[] = [
                        'label'      => $label,
                        'value'      => $value,
                        'calc_value' => '',
                        'image'      => '',
                    ];
                }
                $element['settings']['advanced_options'] = $formattedOptions;
                $element['settings']['enable_image_input'] = false;
                $element['settings']['calc_value_status'] = false;
                unset($element['options']);

                if ('input_radio' == $upgradeElement || 'input_checkbox' == $upgradeElement) {
                    $element['editor_options']['template'] = 'inputCheckable';
                }
            }

            if (!isset($element['settings']['layout_class']) && in_array($upgradeElement, ['input_radio', 'input_checkbox'])) {
                $element['settings']['layout_class'] = '';
            }

            if (!isset($element['settings']['dynamic_default_value'])) {
                $element['settings']['dynamic_default_value'] = '';
            }

            if ('select_country' != $upgradeElement && !isset($element['settings']['randomize_options'])) {
                $element['settings']['randomize_options'] = 'no';
            }

            if ('select' == $upgradeElement && \FluentForm\Framework\Helpers\ArrayHelper::get($element, 'attributes.multiple')) {
                if (empty($element['settings']['max_selection'])) {
                    $element['settings']['max_selection'] = '';
                }
                if (isset($element['settings']['enable_select_2'])) {
                    \FluentForm\Framework\Helpers\ArrayHelper::forget($element, 'settings.enable_select_2');
                }
            }

            if (
                (
                    (
                        'select' == $upgradeElement &&
                        !\FluentForm\Framework\Helpers\ArrayHelper::get($element, 'attributes.multiple')
                    ) ||
                    'select_country' == $upgradeElement
                ) &&
                !isset($element['settings']['enable_select_2'])
            ) {
                $element['settings']['enable_select_2'] = 'no';
            }

            if ('select_country' != $upgradeElement && !isset($element['settings']['values_visible'])) {
                $element['settings']['values_visible'] = false;
            }

            if ('select' == $upgradeElement && !isset($element['settings']['enable_option_groups'])) {
                $element['settings']['enable_option_groups'] = 'no';
            }

            return $element;
        });
    }

    $upgradableFileInputs = [
        'input_file',
        'input_image',
    ];
    foreach ($upgradableFileInputs as $upgradeElement) {
        add_filter('fluentform/editor_init_element_' . $upgradeElement, function ($element) {
            if (!isset($element['settings']['upload_file_location'])) {
                $element['settings']['upload_file_location'] = 'default';
            }
            if (!isset($element['settings']['file_location_type'])) {
                $element['settings']['file_location_type'] = 'follow_global_settings';
            }
            if ('input_image' === $element['element']) {
                if (!isset($element['settings']['enable_crop'])) {
                    $element['settings']['enable_crop'] = 'no';
                }
                if (!isset($element['settings']['crop_mode'])) {
                    $element['settings']['crop_mode'] = (
                        isset($element['settings']['enforce_image_dimensions']) &&
                        'yes' === $element['settings']['enforce_image_dimensions']
                    ) ? 'dimensions' : 'ratio';
                }
                if (!isset($element['settings']['crop_ratio'])) {
                    $element['settings']['crop_ratio'] = 'free';
                }
                if (!isset($element['settings']['enforce_image_dimensions'])) {
                    $element['settings']['enforce_image_dimensions'] = 'no';
                }
                if (!isset($element['settings']['crop_width'])) {
                    $element['settings']['crop_width'] = '';
                }
                if (!isset($element['settings']['crop_height'])) {
                    $element['settings']['crop_height'] = '';
                }
            }
            return $element;
        });
    }

    $prefixSuffixInputs = [
        'textarea',
        'input_url',
        'input_password',
    ];

    foreach ($prefixSuffixInputs as $inputType) {
        add_filter('fluentform/editor_init_element_' . $inputType, function ($item) {
            if (!isset($item['settings']['prefix_label'])) {
                $item['settings']['prefix_label'] = '';
            }
            if (!isset($item['settings']['suffix_label'])) {
                $item['settings']['suffix_label'] = '';
            }
            return $item;
        });
    }

    add_filter('fluentform/editor_init_element_gdpr_agreement', function ($element) {
        if (!isset($element['settings']['required_field_message'])) {
            $element['settings']['required_field_message'] = '';
        }
        return $element;
    });

    add_filter('fluentform/editor_init_element_input_text', function ($element) {
        if (!isset($element['attributes']['maxlength'])) {
            $element['attributes']['maxlength'] = '';
        }
        return $element;
    });

    add_filter('fluentform/editor_init_element_textarea', function ($element) {
        if (!isset($element['attributes']['maxlength'])) {
            $element['attributes']['maxlength'] = '';
        }
        return $element;
    });

    add_filter('fluentform/editor_init_element_input_date', function ($item) {
        if (!isset($item['settings']['date_config'])) {
            $item['settings']['date_config'] = '';
        }
        return $item;
    });

    add_filter('fluentform/editor_init_element_ratings', function ($item) {
        if (!isset($item['settings']['icon_source'])) {
            $item['settings']['icon_source'] = 'preset';
        }

        if (!isset($item['settings']['icon_type'])) {
            $item['settings']['icon_type'] = \FluentForm\App\Services\FormBuilder\RatingIcon::DEFAULT_ICON;
        }

        if (!isset($item['settings']['custom_icon_svg'])) {
            $item['settings']['custom_icon_svg'] = '';
        }

        if (!isset($item['settings']['inactive_color'])) {
            $item['settings']['inactive_color'] = \FluentForm\App\Services\FormBuilder\RatingIcon::DEFAULT_INACTIVE_COLOR;
        }

        if (!isset($item['settings']['active_color'])) {
            $item['settings']['active_color'] = \FluentForm\App\Services\FormBuilder\RatingIcon::DEFAULT_ACTIVE_COLOR;
        }

        return $item;
    });

    add_filter('fluentform/editor_init_element_container', function ($item) {
        if (!isset($item['settings']['conditional_logics'])) {
            $item['settings']['conditional_logics'] = [];
        }

        if (!isset($item['settings']['container_width'])) {
            $item['settings']['container_width'] = '';
        }

        if (!isset($item['settings']['is_width_auto_calc'])) {
            $item['settings']['is_width_auto_calc'] = true;
        }

        if (!isset($item['settings']['render_recaptcha_v3_badge'])) {
            $item['settings']['render_recaptcha_v3_badge'] = false;
        }

        $shouldSetWidth = !empty($item['columns']) && (!isset($item['columns'][0]['width']) || !$item['columns'][0]['width']);

        if ($shouldSetWidth) {
            $perColumn = round(100 / count($item['columns']), 2);

            foreach ($item['columns'] as &$column) {
                $column['width'] = $perColumn;
            }
        }

        return $item;
    });

    add_filter('fluentform/editor_init_element_input_number', function ($item) {
        if (!isset($item['settings']['number_step'])) {
            $item['settings']['number_step'] = '';
        }
        if (!isset($item['settings']['numeric_formatter'])) {
            $item['settings']['numeric_formatter'] = '';
        }
        if (!isset($item['settings']['prefix_label'])) {
            $item['settings']['prefix_label'] = '';
        }
        if (!isset($item['settings']['suffix_label'])) {
            $item['settings']['suffix_label'] = '';
        }
        if (!isset($item['settings']['mobile_keyboard_type_number'])) {
            $item['settings']['mobile_keyboard_type_number'] = '';
        }

        return $item;
    });

    add_filter('fluentform/editor_init_element_input_mask', function ($item) {
        if (!isset($item['settings']['mobile_keyboard_type'])) {
            $item['settings']['mobile_keyboard_type'] = '';
        }
        return $item;
    });

    add_filter('fluentform/editor_init_element_input_email', function ($item) {
        if (!isset($item['settings']['is_unique'])) {
            $item['settings']['is_unique'] = 'no';
        }
        if (!isset($item['settings']['unique_validation_message'])) {
            $item['settings']['unique_validation_message'] = __('Email address need to be unique.', 'fluentform');
        }
        if (!isset($item['settings']['prefix_label'])) {
            $item['settings']['prefix_label'] = '';
        }
        if (!isset($item['settings']['suffix_label'])) {
            $item['settings']['suffix_label'] = '';
        }
        return $item;
    });

    add_filter('fluentform/editor_init_element_input_text', function ($item) {
        if (isset($item['attributes']['data-mask'])) {
            if (!isset($item['settings']['data-mask-reverse'])) {
                $item['settings']['data-mask-reverse'] = 'no';
            }
            if (!isset($item['settings']['data-clear-if-not-match'])) {
                $item['settings']['data-clear-if-not-match'] = 'no';
            }
        } else {
            if (!isset($item['settings']['is_unique'])) {
                $item['settings']['is_unique'] = 'no';
            }
            if (!isset($item['settings']['unique_validation_message'])) {
                $item['settings']['unique_validation_message'] = __('This field value need to be unique.', 'fluentform');
            }
        }

        if (!isset($item['settings']['prefix_label'])) {
            $item['settings']['prefix_label'] = '';
        }
        if (!isset($item['settings']['suffix_label'])) {
            $item['settings']['suffix_label'] = '';
        }
        return $item;
    });

    if ($inputs = \FluentForm\App\Modules\Form\FormFieldsParser::getInputs($form, ['element'])) {
        foreach ($inputs as $input) {
            add_filter('fluentform/editor_init_element_' . $input['element'], function ($field) {
                Helper::resolveValidationRulesGlobalOption($field);
                return $field;
            });
        }
    }

    add_filter('fluentform/editor_init_element_recaptcha', function ($item, $form) {
        $item['attributes']['name'] = 'g-recaptcha-response';
        return $item;
    }, 10, 2);

    add_filter('fluentform/editor_init_element_hcaptcha', function ($item, $form) {
        $item['attributes']['name'] = 'h-captcha-response';
        return $item;
    }, 10, 2);

    add_filter('fluentform/editor_init_element_turnstile', function ($item, $form) {
        $item['attributes']['name'] = 'cf-turnstile-response';
        return $item;
    }, 10, 2);

    add_filter('fluentform/editor_init_element_address', function ($item) {
        // Initialize autocomplete provider settings
        if (!isset($item['settings']['autocomplete_provider'])) {
            // If google autocomplete setting is enabled, set provider to google
            if (ArrayHelper::get($item, 'settings.enable_g_autocomplete') === 'yes') {
                $item['settings']['autocomplete_provider'] = 'google';
            } else {
                $item['settings']['autocomplete_provider'] = 'none';
            }
        }
        if (!isset($item['settings']['enable_auto_locate'])) {
            $item['settings']['enable_auto_locate'] = 'on_click'; // on_load, on_click, no
        }
        if (!isset($item['settings']['save_coordinates'])) {
            $item['settings']['save_coordinates'] = 'no';
        }

        foreach ($item['fields'] as &$addressField) {
            if (
                !isset($addressField['settings']['label_placement']) &&
                !isset($addressField['settings']['label_placement_options'])
            ) {
                $addressField['settings']['label_placement'] = '';
                $addressField['settings']['label_placement_options'] = [
                    [
                        'value' => '',
                        'label' => __('Default', 'fluentform'),
                    ],
                    [
                        'value' => 'top',
                        'label' => __('Top', 'fluentform'),
                    ],
                    [
                        'value' => 'right',
                        'label' => __('Right', 'fluentform'),
                    ],
                    [
                        'value' => 'bottom',
                        'label' => __('Bottom', 'fluentform'),
                    ],
                    [
                        'value' => 'left',
                        'label' => __('Left', 'fluentform'),
                    ],
                    [
                        'value' => 'hide_label',
                        'label' => __('Hidden', 'fluentform'),
                    ],
                ];
            }
        }
        return $item;
    });

    add_filter('fluentform/editor_init_element_gdpr_agreement', function ($item, $form) {
        $isConversationalForm = Helper::isConversionForm($form->id);

        if ($isConversationalForm) {
            $item['settings']['tc_agree_text'] = __('I accept', 'fluentform');
        }

        return $item;
    }, 10, 2);

    add_filter('fluentform/editor_init_element_terms_and_condition', function ($item, $form) {
        $isConversationalForm = Helper::isConversionForm($form->id);

        if ($isConversationalForm) {
            $item['settings']['hide_disagree'] = false;
        }

        return $item;
    }, 10, 2);
}, 10);

$app->addAction('fluentform/addons_page_render_fluentform_pdf', function () use ($app) {
    $url = '';
    if (!defined('FLUENTFORM_PDF_VERSION')) {
        $url = wp_nonce_url(
            self_admin_url('update.php?action=install-plugin&plugin=fluentforms-pdf'),
            'install-plugin_fluentforms-pdf'
        );
    }

    $app->view->render('admin.addons.pdf_promo', [
        'public_url'   => fluentFormMix(),
        'install_url'  => $url,
        'is_installed' => defined('FLUENTFORM_PDF_VERSION'),
    ]);
});

$app->addAction('fluentform/installed_by', function ($by) {
    if (is_string($by) && !get_option('_ff_ins_by')) {
        update_option('_ff_ins_by', sanitize_text_field($by), 'no');
    }
});

// from Frontend.php
if (defined('WP_ROCKET_VERSION')) {
    add_filter('rocket_excluded_inline_js_content', function ($lines) {
        $lines[] = 'fluent_form_ff_form_instance';
        $lines[] = 'fluentFormVars';
        $lines[] = 'fluentform_payment';

        return $lines;
    });
}

// from Common.php
add_action('save_post', function ($post_id) use ($app) {

    if (!is_post_type_viewable(get_post_type($post_id))) {
        return;
    }

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified by WordPress save_post action
    $post_content = isset($_REQUEST['post_content']) ? wp_kses_post(wp_unslash($_REQUEST['post_content'])) : false;
    if (!$post_content || !is_string($post_content)) {
        $post = get_post($post_id);
        $post_content = $post->post_content;
    }

    $shortcodeIds = Helper::getShortCodeIds(
        $post_content,
        'fluentform',
        'id'
    );

    $attributes = ArrayHelper::get($shortcodeIds, 'attributes', []);
    ArrayHelper::forget($shortcodeIds, 'attributes');

    $shortcodeModalIds = Helper::getShortCodeIds(
        $post_content,
        'fluentform_modal',
        'form_id'
    );

    $gutenbergIds = Helper::getFormsIdsFromBlocks($post_content);

    if ($shortcodeModalIds) {
        $modalAttributes = ArrayHelper::get($shortcodeModalIds, 'attributes', []);
        ArrayHelper::forget($shortcodeModalIds, 'attributes');

        $shortcodeIds = array_merge($shortcodeIds, $shortcodeModalIds);

        if ($modalAttributes) {
            $attributes = array_merge($attributes, $modalAttributes);
        }
    }

    if ($gutenbergIds) {
        $blockAttributes = ArrayHelper::get($gutenbergIds, 'attributes', []);
        ArrayHelper::forget($gutenbergIds, 'attributes');

        $shortcodeIds = array_merge($shortcodeIds, $gutenbergIds);

        if ($blockAttributes) {
            $attributes = array_merge($attributes, $blockAttributes);
        }
    }

    $shortcodeIds = array_unique($shortcodeIds);

    if ($attributes) {
        $data = [];

        foreach ($attributes as $attribute) {
            $data[$attribute['formId']]['themes'][] = $attribute['theme'];
        }

        $shortcodeIds['attributes'] = $data;
    }

    if ($shortcodeIds) {
        update_post_meta($post_id, '_has_fluentform', $shortcodeIds);
    } elseif (get_post_meta($post_id, '_has_fluentform', true)) {
        update_post_meta($post_id, '_has_fluentform', []);
    }
});

$fluentformComponent = new Component($app);
$fluentformComponent->addRendererActions();
$fluentformComponent->addFluentFormShortCode();
$fluentformComponent->addFluentFormDefaultValueParser();
$fluentformComponent->addFluentformSubmissionInsertedFilter();
$fluentformComponent->addIsRenderableFilter();
$fluentformComponent->registerInputSanitizers();

add_action('wp', function () use ($app) {
    // @todo: We will remove the fluentform_pages check from April 2021
    $fluentFormPages = $app->request->get('fluent_forms_pages') || $app->request->get('fluentform_pages');

    if ($fluentFormPages) {
        add_action('wp_enqueue_scripts', function () use ($app) {
            wp_enqueue_script('jquery');
            wp_enqueue_script(
                'fluent_forms_global',
                fluentFormMix('js/fluent_forms_global.js'),
                ['jquery'],
                FLUENTFORM_VERSION,
                true
            );
            $globalVars = [
                'ajaxurl'              => Helper::getAjaxUrl(),
                'global_search_active' => apply_filters('fluentform/global_search_active', 'yes'),
                'rest'                 => Helper::getRestInfo(),
            ];
            if (Acl::hasAnyFormPermission()) {
                $globalVars['fluent_forms_admin_nonce'] = wp_create_nonce('fluent_forms_admin_nonce');
            }
            wp_localize_script('fluent_forms_global', 'fluent_forms_global_var', $globalVars);
            wp_enqueue_style('fluent-form-styles');
            $form = wpFluent()->table('fluentform_forms')->find(intval($app->request->get('preview_id')));
            $postId = get_the_ID() ? get_the_ID() : 0;

            $loadPublicStyle = apply_filters_deprecated(
                'fluentform_load_default_public',
                [
                    true,
                    $form,
                    $postId,
                ],
                FLUENTFORM_FRAMEWORK_UPGRADE,
                'fluentform/load_default_public',
                'Use fluentform/load_default_public instead of fluentform_load_default_public.'
            );

            if (apply_filters('fluentform/load_default_public', $loadPublicStyle, $form, $postId)) {
                wp_enqueue_style('fluentform-public-default');
            }
            wp_enqueue_script('fluent-form-submission');
            wp_enqueue_style('fluent-form-preview', fluentFormMix('css/preview.css'), [], FLUENTFORM_VERSION);
            if (!defined('FLUENTFORMPRO')) {
                wp_enqueue_script(
                    'fluentform-preview_app',
                    fluentFormMix('js/form_preview_app.js'),
                    ['jquery'],
                    FLUENTFORM_VERSION,
                    true
                );

                wp_localize_script('fluentform-preview_app', 'fluent_preview_var', [
                    'i18n'    => \FluentForm\App\Modules\Registerer\TranslationString::getPreviewI18n(),
                ]);
            }
        });

        (new \FluentForm\App\Modules\ProcessExteriorModule())->handleExteriorPages();
    }
}, 1);

// Register api response log hooks
$app->addAction(
    'fluentform/after_submission_api_response_success',
    function ($form, $entryId, $data, $feed, $res, $msg = '') {
        fluentform_after_submission_api_response_success($form, $entryId, $data, $feed, $res, $msg = '');
    },
    10,
    6
);

$app->addAction(
    'fluentform/after_submission_api_response_failed',
    function ($form, $entryId, $data, $feed, $res, $msg = '') {
        fluentform_after_submission_api_response_failed($form, $entryId, $data, $feed, $res, $msg = '');
    },
    10,
    6
);

function fluentform_after_submission_api_response_success($form, $entryId, $data, $feed, $res, $msg = '')
{
    try {
        $isDev = 'production' != wpFluentForm()->getEnv();

        $isDev = apply_filters_deprecated(
            'fluentform_api_success_log',
            [
                $isDev,
                $form,
                $feed,
            ],
            FLUENTFORM_FRAMEWORK_UPGRADE,
            'fluentform/api_success_log',
            'Use fluentform/api_success_log instead of fluentform_api_success_log.'
        );

        if (!apply_filters('fluentform/api_success_log', $isDev, $form, $feed)) {
            return;
        }

        wpFluent()->table('fluentform_submission_meta')->insert([
            'response_id' => $entryId,
            'form_id'     => $form->id,
            'meta_key'    => 'api_log',
            'value'       => $msg,
            'name'        => $feed->formattedValue['name'],
            'status'      => 'success',
            'created_at'  => current_time('mysql'),
            'updated_at'  => current_time('mysql'),
        ]);
    } catch (Exception $e) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging only when WP_DEBUG is enabled, helps developers troubleshoot shortcode parsing issues
            error_log($e->getMessage());
        }
        return '';
    }
}

function fluentform_after_submission_api_response_failed($form, $entryId, $data, $feed, $res, $msg = '')
{
    try {
        $isDev = 'production' != wpFluentForm()->getEnv();

        $isDev = apply_filters_deprecated(
            'fluentform_api_failed_log',
            [
                $isDev,
                $form,
                $feed,
            ],
            FLUENTFORM_FRAMEWORK_UPGRADE,
            'fluentform/api_failed_log',
            'Use fluentform/api_failed_log instead of fluentform_api_failed_log.'
        );

        if (!apply_filters('fluentform/api_failed_log', $isDev, $form, $feed)) {
            return;
        }

        wpFluent()->table('fluentform_submission_meta')->insert([
            'response_id' => $entryId,
            'form_id'     => $form->id,
            'meta_key'    => 'api_log',
            'value'       => json_encode($res),
            'name'        => $feed->formattedValue['name'],
            'status'      => 'failed',
            'created_at'  => current_time('mysql'),
            'updated_at'  => current_time('mysql'),
        ]);
    } catch (Exception $e) {
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Intentional logging for debugging
        error_log($e->getMessage());
    }
}

$app->addAction('fluentform/before_form_render', function ($form, $atts) {
    $theme = ArrayHelper::get($atts, 'theme');

    $styles = $theme ? [$theme] : [];

    do_action(
        'fluentform/load_form_assets',
        $form->id,
        $styles
    );
}, 10, 2);

add_action('fluentform/load_form_assets', function ($formId, $styles = []) {
    $formAssetLoader = (new \FluentForm\App\Modules\Form\Settings\FormCssJs());

    $formAssetLoader->addCustomCssJs($formId);

    $notLoadedStyles = [];

    foreach ($styles as $style) {
        if (!did_action('fluent_form/loaded_styler_' . $formId . '_' . $style)) {
            $notLoadedStyles[] = $style;
        }
    }

    // check if already loaded
    if ($notLoadedStyles) {
        $formAssetLoader->addStylerCSS($formId, $notLoadedStyles);
    }
}, 10, 2);

$app->addAction('fluentform/submission_inserted', function ($insertId, $formData, $form) use ($app) {
    $notificationManager = new \FluentForm\App\Hooks\Handlers\GlobalNotificationHandler($app);
    $notificationManager->globalNotify($insertId, $formData, $form);
}, 10, 3);

$app->addAction('fluentform/schedule_feed', function ($queueId) use ($app) {
    $scheduler = $app['fluentFormAsyncRequest'];

    $scheduler->process($queueId);
});

$app->addAction('init', function () use ($app) {
    new \FluentForm\App\Services\Integrations\MailChimp\MailChimpIntegration($app);
    new \FluentForm\App\Modules\Form\TokenBasedSpamProtection($app);
    // Load payment module
    if (Helper::isPaymentCompatible()) {
        (new FluentForm\App\Modules\Payments\PaymentHandler())->init();
    }
});

$app->addAction('fluentform/form_element_start', function ($form) use ($app) {
    $honeyPot = new \FluentForm\App\Modules\Form\HoneyPot($app);
    $honeyPot->renderHoneyPot($form);

    $tokenBasedSpamProtection = new \FluentForm\App\Modules\Form\TokenBasedSpamProtection($app);
    $tokenBasedSpamProtection->renderTokenField($form);

    $cleanTalk = new \FluentForm\App\Modules\Form\CleanTalkHandler();
    $cleanTalk->setCleanTalkScript();
});

$app->addAction('fluentform/before_insert_submission', function ($insertData, $requestData, $form) use ($app) {
    $honeyPot = new \FluentForm\App\Modules\Form\HoneyPot($app);
    $honeyPot->verify($insertData, $requestData, $form->id);

    $tokenBasedSpamProtection = new \FluentForm\App\Modules\Form\TokenBasedSpamProtection($app);
    $tokenBasedSpamProtection->verify($insertData, $requestData, $form->id);
}, 9, 3);

// The token-based spam check (FINDING-25) enforces on conversational forms too, but its ~1h TTL
// token cannot be refreshed by the conversational JS app — it bakes hidden inputs statically at
// render, so behind a full-page cache the token expires and rejects every legitimate submission.
// Disable ONLY the token for conversational forms, resolved from server-side form meta (never the
// client-supplied isFFConversational flag, which was the original bypass). The honeypot still applies.
$app->addFilter('fluentform/token_based_spam_protection_status', function ($status, $formId) {
    if ($status && \FluentForm\App\Helpers\Helper::isConversionForm($formId)) {
        return false;
    }
    return $status;
}, 10, 2);

// Maybe update current user allowed form ids,
// if current user has specific form permission and capable to create form
$app->addAction('fluentform/inserted_new_form', function ($formId) {
    \FluentForm\App\Services\Manager\FormManagerService::maybeAddUserAllowedFormIds($formId);
});

add_action('fluentform/log_data', function ($data) use ($app) {
    $dataLogger = new \FluentForm\App\Modules\Logger\DataLogger($app);
    $dataLogger->log($data);
});

// Support for third party plugin who do_action this hook on previous way (before 5.0.0 way)
// In Fluent Forms 5.0.0 'ff_log_data' add_action replaced with action named 'fluentform/log_data'.
// @todo - notify them for updating do_action name 'fluentform/log_data'.
// @todo - We will remove bellow add_action after 2 or more version release latter.
add_action('ff_log_data', function ($data) use ($app) {
    $dataLogger = new \FluentForm\App\Modules\Logger\DataLogger($app);
    $dataLogger->log($data);
});

// widgets
add_action('widgets_init', function () {
    register_widget('FluentForm\App\Modules\Widgets\SidebarWidgets');
});

add_action('wp', function () {
    global $post;

    if (!is_a($post, 'WP_Post')) {
        return;
    }

    $fluentFormIds = get_post_meta($post->ID, '_has_fluentform', true);
    $attributes = ArrayHelper::get($fluentFormIds, 'attributes', []);

    if (isset($fluentFormIds['attributes'])) {
        unset($fluentFormIds['attributes']);
    }

    if ($fluentFormIds && is_array($fluentFormIds)) {
        foreach ($fluentFormIds as $formId) {
            do_action(
                'fluentform/load_form_assets',
                $formId,
                array_unique(ArrayHelper::get($attributes, $formId . '.themes', []))
            );
        }
    }
});

add_filter('cron_schedules', function ($schedules) {
    $schedules['ff_every_five_minutes'] = [
        'interval' => 300,
        'display'  => 'Every 5 minutes (FluentForm)',
    ];

    return $schedules;
}, 10, 1);

add_action('fluentform_do_scheduled_tasks', 'fluentFormHandleScheduledTasks');
add_action('fluentform_do_email_report_scheduled_tasks', 'fluentFormHandleScheduledEmailReport');

add_action('fluentform/integration_action_result', function ($feed, $status, $note = '') {
    if (!isset($feed['scheduled_action_id']) || !$status) {
        return;
    }
    if (!$note) {
        $note = $status;
    }

    $note = is_scalar($note)
        ? sanitize_text_field(wp_unslash((string) $note))
        : sanitize_text_field((string) wp_json_encode($note));

    if (strlen($note) > 255) {
        if (function_exists('mb_substr')) {
            $note = mb_substr($note, 0, 251) . '...';
        } else {
            $note = substr($note, 0, 251) . '...';
        }
    }

    $actionId = intval($feed['scheduled_action_id']);
    wpFluent()->table('ff_scheduled_actions')
        ->where('id', $actionId)
        ->update([
            'status'     => $status,
            'note'       => $note,
            'updated_at' => current_time('mysql'),
        ]);
}, 10, 3);


// Support for third party plugin who do_action this hook on previous way (before 5.0.0 way)
// In Fluent Forms 5.0.0 'ff_integration_action_result' add_action replaced in above action named 'fluentform/integration_action_result'.
// @todo - notify them for updating do_action name 'fluentform/integration_action_result'.
// @todo - We will remove bellow add_action after 2 or more version release latter.
add_action('ff_integration_action_result', function ($feed, $status, $note = '') {
    if (!isset($feed['scheduled_action_id']) || !$status) {
        return;
    }
    if (!$note) {
        $note = $status;
    }

    $note = is_scalar($note)
        ? sanitize_text_field(wp_unslash((string) $note))
        : sanitize_text_field((string) wp_json_encode($note));

    if (strlen($note) > 255) {
        if (function_exists('mb_substr')) {
            $note = mb_substr($note, 0, 251) . '...';
        } else {
            $note = substr($note, 0, 251) . '...';
        }
    }

    $actionId = intval($feed['scheduled_action_id']);
    wpFluent()->table('ff_scheduled_actions')
        ->where('id', $actionId)
        ->update([
            'status' => $status,
            'note'   => $note,
        ]);
}, 10, 3);

add_action('fluentform/global_notify_completed', function ($insertId, $form) use ($app) {
    $isTruncate = apply_filters_deprecated(
        'fluentform_truncate_password_values',
        [
            true,
            $form->id,
        ],
        FLUENTFORM_FRAMEWORK_UPGRADE,
        'fluentform/truncate_password_values',
        'Use fluentform/truncate_password_values instead of fluentform_truncate_password_values.'
    );

    if (strpos($form->form_fields, '"element":"input_password"') && apply_filters('fluentform/truncate_password_values', $isTruncate, $form->id)) {
        // we have password
        (new \FluentForm\App\Services\Integrations\GlobalNotificationService())->cleanUpPassword($insertId, $form);
    }
}, 10, 2);

/*
 * Elementor Block Init
 */

if (defined('ELEMENTOR_VERSION')) {
    new \FluentForm\App\Modules\Widgets\ElementorWidget($app);
}
/*
 * Oxygen Widget Init
 */

add_action('init', function () {
    if (class_exists('OxyEl')) {
        if (file_exists(FLUENTFORM_DIR_PATH . 'app/Modules/Widgets/OxygenWidget.php')) {
            new FluentForm\App\Modules\Widgets\OxygenWidget();
        }
    }
});

(new FluentForm\App\Services\Integrations\Slack\SlackNotificationActions($app))->register();

/*
 * Smartcode parser shortcodes
 */

new \FluentForm\App\Services\FormBuilder\Components\CustomSubmitButton();

add_action('enqueue_block_editor_assets', function () {

    wp_enqueue_script(
        'fluentform-gutenberg-block',
        fluentFormMix('js/fluent_gutenblock.js'),
        ['wp-element', 'wp-polyfill', 'wp-i18n', 'wp-blocks', 'wp-components','wp-server-side-render', 'wp-block-editor'],
        FLUENTFORM_VERSION,
        true
    );
    wp_enqueue_style(
        'fluentform-gutenberg-block',
        fluentFormMix('css/fluent_gutenblock.css'),
        ['wp-edit-blocks'],
        FLUENTFORM_VERSION
    );

    $forms = wpFluent()->table('fluentform_forms')
        ->select(['id', 'title'])
        ->orderBy('id', 'DESC')
        ->get()
        ->toArray();

    array_unshift($forms, (object) [
        'id'    => '',
        'title' => __('-- Select a form --', 'fluentform'),
    ]);

    $presets = [
        [
            'label' => __('Default (Form Styler)', 'fluentform'),
            'value' => '',
        ],
        [
            'label' => __('Inherit Theme Style', 'fluentform'),
            'value' => 'ffs_inherit_theme',
        ],
    ];

    $presets = apply_filters('fluentform/block_editor_style_presets', $presets);

    wp_localize_script('fluentform-gutenberg-block', 'fluentform_block_vars', [
        'logo'                    => fluentFormMix('img/fluent_icon.svg'),
        'forms'                   => $forms,
        'style_presets'           => $presets,
        'theme_style'             => apply_filters('fluentform/load_theme_style', false) ? 'ffs_inherit_theme' : '',
        'conversational_demo_img' => fluentFormMix('img/conversational-form-demo.png'),
        'rest'                    => Helper::getRestInfo(),
    ]);

    wp_enqueue_style(
        'fluentform-gutenberg-block',
        fluentFormMix('css/fluent_gutenblock.css'),
        ['wp-edit-blocks'],
        FLUENTFORM_VERSION
    );
    $fluentFormPublicCss = fluentFormMix('css/fluent-forms-public.css');
    $fluentFormPublicDefaultCss = fluentFormMix('css/fluentform-public-default.css');

    if (is_rtl()) {
        $fluentFormPublicCss = fluentFormMix('css/fluent-forms-public-rtl.css');
        $fluentFormPublicDefaultCss = fluentFormMix('css/fluentform-public-default-rtl.css');
    }

    wp_enqueue_style(
        'fluent-form-styles',
        $fluentFormPublicCss,
        [],
        FLUENTFORM_VERSION
    );

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Checking post ID in admin context
    $post_id = isset($_GET['post']) ? (int) $_GET['post'] : 0;
    $loadPublicStyle = apply_filters_deprecated(
        'fluentform_load_default_public',
        [
            true,
            (object) [],
            $post_id,
        ],
        FLUENTFORM_FRAMEWORK_UPGRADE,
        'fluentform/load_default_public',
        'Use fluentform/load_default_public instead of fluentform_load_default_public.'
    );

    if (apply_filters('fluentform/load_default_public', $loadPublicStyle, (object) [], $post_id)) {
        wp_enqueue_style(
            'fluentform-public-default',
            $fluentFormPublicDefaultCss,
            [],
            FLUENTFORM_VERSION
        );
    }
});


if (function_exists('register_block_type')) {
    add_action('init', function () {
        // Use the dedicated GutenbergBlock class for block registration and rendering
        \FluentForm\App\Services\Blocks\GutenbergBlock::register();
    });
}


add_action('fluentform/before_updating_form', function ($form, $postData) {
    (new FluentForm\App\Services\Form\HistoryService())->init($form, $postData);
}, 10, 2);


// WordPress 6.3+ uses iframes for block editor preview
// Official WordPress solution: Use enqueue_block_assets with proper context checking
// See: https://make.wordpress.org/core/2023/07/18/miscellaneous-editor-changes-in-wordpress-6-3/
add_action('enqueue_block_assets', function () {
    // enqueue_block_assets also fires on the front end, where wp_enqueue_scripts already loads these conditionally.
    if (!is_admin()) {
        return;
    }

    $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($current_screen && !$current_screen->is_block_editor()) {
        return;
    }

    // Enqueue Fluent Forms CSS for block editor iframe preview
    // These styles are necessary for the live form preview in the block editor
    wp_enqueue_style('fluent-forms-public', fluentFormMix('css/fluent-forms-public.css'), [], FLUENTFORM_VERSION);
    wp_enqueue_style('fluentform-public-default', fluentFormMix('css/fluentform-public-default.css'), [], FLUENTFORM_VERSION);
});



// require the CLI
if (defined('WP_CLI') && WP_CLI) {
    \WP_CLI::add_command('fluentform', '\FluentForm\App\Modules\CLI\Commands');
}
