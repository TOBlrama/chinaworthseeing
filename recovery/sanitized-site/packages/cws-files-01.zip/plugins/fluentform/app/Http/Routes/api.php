<?php

defined('ABSPATH') || exit;

/**
 * REST API route definitions.
 *
 * @var $router \FluentForm\Framework\Http\Router
 */

/*
* Forms resource
*/
$router->prefix('forms')->withPolicy('FormPolicy')->group(function ($router) {
    $router->get('/', 'FormController@index');
    $router->post('/', 'FormController@store');
    $router->get('templates', 'FormController@templates');
    $router->get('ping', 'FormController@ping');

    $router->prefix('{form_id}')->group(function ($router) {
        $router->get('/', 'FormController@find');
        $router->post('/', 'FormController@update');
        $router->delete('/', 'FormController@delete');
        $router->post('duplicate', 'FormController@duplicate');
        $router->post('convert', 'FormController@convert');
        $router->get('resources', 'FormController@resources');
        $router->get('pages', 'FormController@pages');
        $router->get('fields', 'FormController@fields');
        $router->get('shortcodes', 'FormController@shortcodes');
        $router->get('findShortCodePage', 'FormController@findShortCodePage');
        $router->get('editHistory', 'FormController@formEditHistory');
        $router->post('clearHistory', 'FormController@clearEditHistory');
    });
});

/*
* Form Settings
*/
$router->prefix('settings')->withPolicy('FormPolicy')->group(function ($router) {
    $router->prefix('{form_id}')->group(function ($router) {
        $router->get('/', 'FormSettingsController@index');
        $router->post('/', 'FormSettingsController@store');
        $router->delete('/', 'FormSettingsController@remove');

        $router->get('general', 'FormSettingsController@general');
        $router->post('general', 'FormSettingsController@saveGeneral');

        $router->get('customizer', 'FormSettingsController@customizer');
        $router->post('customizer', 'FormSettingsController@storeCustomizer');

        $router->post('entry-columns', 'FormSettingsController@storeEntryColumns');

        $router->get('conversational-design', 'FormSettingsController@conversationalDesign');
        $router->post('store-conversational-design', 'FormSettingsController@storeConversationalDesign');
        $router->get('preset', 'FormSettingsController@getPreset');
        $router->post('save-preset', 'FormSettingsController@savePreset');
    });
});
/*
* Form Submissions
*/
$router->prefix('submissions')->withPolicy('SubmissionPolicy')->group(function ($router) {
    $router->get('/', 'SubmissionController@index');
    $router->get('resources', 'SubmissionController@resources');
    $router->post('bulk-actions', 'SubmissionController@handleBulkActions');
    $router->get('print', 'SubmissionController@print');
    $router->get('all', 'SubmissionController@all');
    $router->delete('/{entry_id}', 'SubmissionController@remove');

    $router->prefix('{entry_id}')->group(function ($router) {
        $router->get('/', 'SubmissionController@find');

        $router->post('status', 'SubmissionController@updateStatus');
        $router->post('is-favorite', 'SubmissionController@toggleIsFavorite');

        $router->get('logs', 'SubmissionLogController@get');
        $router->delete('logs', 'SubmissionLogController@remove');

        $router->get('notes', 'SubmissionNoteController@get');
        $router->post('notes', 'SubmissionNoteController@store');

        $router->get('submission-users', 'SubmissionController@submissionUsers');
        $router->post('update-submission-user', 'SubmissionController@updateSubmissionUser');
    });
});

/*
* Logs
*/
$router->prefix('logs')->withPolicy('SubmissionPolicy')->group(function ($router) {
    $router->get('/', 'LogController@get');
    $router->delete('/', 'LogController@remove');
    $router->get('/filters', 'LogController@getFilters');
});
/*
* Global Integrations
*/
$router->prefix('integrations')->group(function ($router) {
    $router->get('/', 'GlobalIntegrationController@index')->withPolicy('GlobalIntegrationPolicy');
    $router->post('/', 'GlobalIntegrationController@updateIntegration')->withPolicy('GlobalIntegrationPolicy');
    $router->post('update-status', 'GlobalIntegrationController@updateModuleStatus')->withPolicy('GlobalIntegrationPolicy');

    /*
    * Form Integrations
    */
    $router->prefix('{form_id}')->withPolicy('FormPolicy')->group(function ($router) {
        $router->get('/form-integrations', 'FormIntegrationController@index');
        $router->get('/', 'FormIntegrationController@find');
        $router->post('/', 'FormIntegrationController@update');
        $router->delete('/', 'FormIntegrationController@delete');

        $router->get('/integration-list-id', 'FormIntegrationController@integrationListComponent');
    });
});
/*
* Global Settings
*/
$router->prefix('global-settings')->withPolicy('GlobalSettingsPolicy')->group(function ($router) {
    $router->get('/', 'GlobalSettingsController@index');
    $router->post('/', 'GlobalSettingsController@store');
});
/*
* MCP (Model Context Protocol) Settings
*/
$router->prefix('mcp')->withPolicy('GlobalSettingsPolicy')->group(function ($router) {
    $router->get('status', 'McpSettingsController@status');
    $router->post('toggle', 'McpSettingsController@toggle');
    $router->post('install-adapter', 'McpSettingsController@installAdapter');
    $router->get('config-snippets', 'McpSettingsController@getConfigSnippets');
});
/*
* Permission Roles
*/
$router->prefix('roles')->withPolicy('RoleManagerPolicy')->group(function ($router) {
    $router->get('/', 'RolesController@index');
    $router->post('/', 'RolesController@addCapability');
});
/*
* Permission Managers
*/
$router->prefix('managers')->withPolicy('RoleManagerPolicy')->group(function ($router) {
    $router->get('/', 'ManagersController@index');
    $router->post('/', 'ManagersController@addManager');
    $router->delete('/', 'ManagersController@removeManager');
    $router->get('users', 'ManagersController@getUsers');
});


/*
* Form Analytics
*/
$router->prefix('analytics')->withPolicy('FormPolicy')->group(function ($router) {
    $router->post('/{form_id}/reset', 'AnalyticsController@reset');
});

/*
* Form Submission Handler
*/
$router->post('form-submit', 'SubmissionHandlerController@submit')->withPolicy('SubmissionPolicy');
/*
* Form Report
*/
$router->prefix('report')->withPolicy('ReportPolicy')->group(function ($router) {
    // Component-specific endpoints
    $router->get('/overview-chart', 'ReportController@getOverviewChart');
    $router->get('/revenue-chart', 'ReportController@getRevenueChart');
    $router->get('/completion-rate', 'ReportController@getCompletionRate');
    $router->get('/form-stats', 'ReportController@getFormStats');
    $router->get('/heatmap-data', 'ReportController@getHeatmapData');
    $router->get('/country-heatmap', 'ReportController@getCountryHeatmap');
    $router->get('/api-logs', 'ReportController@getApiLogs');
    $router->get('/top-performing-forms', 'ReportController@getTopPerformingForms');
    $router->get('/subscriptions', 'ReportController@getSubscriptions');
    $router->get('/payment-types', 'ReportController@getPaymentTypes');

    // Existing endpoints
    $router->get('/select-forms', 'ReportController@getFormsDropdown');
    $router->get('/net-revenue', 'ReportController@netRevenue');
    $router->get('/submissions-analysis', 'ReportController@submissionsAnalysis');
    $router->post('/submissions', 'ReportController@submissions');
    $router->get('/forms/{form_id}', 'ReportController@form');
});
/*
* Review Query
*/
$router->post('notice', 'AdminNoticeController@noticeActions')->withPolicy('FormPolicy');

/*
* Global Query
*/
$router->get('global-search', 'GlobalSearchController@index')->withPolicy('FormPolicy');

/*
* Suggested Plugins
*/
$router->prefix('suggested-plugins')->withPolicy('FormPolicy')->group(function ($router) {
    $router->post('check-plugin-statuses', 'SuggestedPluginsController@checkPluginStatuses');
    $router->post('install-plugin', 'SuggestedPluginsController@installPlugin');
    $router->post('activate-plugin', 'SuggestedPluginsController@activatePlugin');
});
